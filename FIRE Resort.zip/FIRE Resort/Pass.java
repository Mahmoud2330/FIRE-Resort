/**
 * A Pass has an id number, name, a luxury rating,
 * number of credits and journey points
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Pass{
    private int PassID;
    private String PersonsName;
    private int LuxuryRating;//The luxury rating (1 to 10), a Pass with a rating of 3 is allowed to visit to all islands rated 3 or below. 
    private int Credit; //A Pass is created with an initial number of credits which are decremented when its owner makes a ferry journey.
    private int JourneyPoints;

    //constructor
    public Pass(int PassID, String PersonsName, int LuxuryRating, int Credit){
        this.PassID = PassID;
        this.PersonsName = PersonsName;
        this.LuxuryRating = LuxuryRating;
        this.Credit = Credit;
        JourneyPoints = 0;
    }

    //constructor with empty parameters for a default constructor in the resort class
    public Pass(){

    }

    // accessors
    public int getPassID(){
        return PassID;
    }

    public String getPersonsName(){
        return PersonsName;
    }

    public int getLuxuryRating(){
        return LuxuryRating;
    }

    public int getJourneyPoints(){
        return JourneyPoints;
    }

    public int getCredit(){
        return Credit;
    }
    
    //mutators
    public void setCredit(int C){
        Credit = C;
    }
    
    //method to add credit to the account
    public void addCredit(int Deposit){
        Credit = Credit + Deposit;
    }

    // remove credit however make sure it doesnt create negative number/ keep selling after 0
    public void minusCredit(int Withdraw){
        int tmp = Credit - Withdraw;
        if(tmp < 0 ){

        }else{
            Credit = Credit - Withdraw;
        }
    }

    /* this method allows the pass to use the ferry however if the pass does not have suffecient amount of credit the task stops
    and does nothing however if the amount is suffecient it takes the required amount of credit and adds a journey point*/ 
    public void UseFerry(){
        if(Credit <= 2){

        }else{
            minusCredit(3);
            JourneyPoints = JourneyPoints + 1;
        }
    }

    /* this method converts the journey points to credit, if the journey points are less than 5 the method does not work, if it is greater than
       5, first the remainder of journey points is calculated then journey points minus the remainder then divided by 5 and that amount will be the maximum journey points
       that could be converted to credits, then the journey points go down to the remainder number*/
    public void JtoC(){
        if(JourneyPoints >= 5){
            Credit = Credit + ((JourneyPoints - (JourneyPoints % 5)) / 5); 
            JourneyPoints = JourneyPoints % 5;
        }
    }

    //toString method returns all the information as a string
    public String toString(){
        //System.out.println("Your ID is: " + PassID + ", and your name is: " + PersonsName + ", your luxury rating is: "+ LuxuryRating + ", your credit is: " + Credit + ", your journey points is: " + JourneyPoints);
        return "(" + "PassID: " + PassID + "| Name: " + PersonsName + "| Luxury Rating is: "+ LuxuryRating + "| Credit: " + Credit + "| Journey Points: " + JourneyPoints + ") \n";
    }
}

