
/**
 * Write a description of class EmployeePass here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class EmployeePass extends Pass {
    //feilds for this child class
    private int employeeNumber;
    private String jobDescription;
    private int journeyScore;

    //constructor, the feilds in the "super" or parent class are also in the constructor
    public EmployeePass(int ID, String Name, int employeeNumber, String jobDescription, int journeyScore) {
        super (ID, Name, 10, 0);
        this.employeeNumber = employeeNumber;
        this.jobDescription = jobDescription;
        this.journeyScore = journeyScore; 
    }
    
    // the UseFerry method here is different from the original method in the Pass class, here it simply just adds 1 journey score
    public void UseFerry(){
            journeyScore = journeyScore + 1;
        }

    //to string method that prints out all the details as a string
    public String toString(){
        
        return "(" + "PassID: " + super.getPassID() + "| Name: " + super.getPersonsName() + "| Luxury Rating is: "+ super.getLuxuryRating() + "| Credit: " + super.getCredit() + "|  Employee number: " + this.employeeNumber + "| Job Description is: " + this.jobDescription + "| Journey Score: " + this.journeyScore +") \n";
    }
}
