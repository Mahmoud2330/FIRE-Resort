import java.util.*;
public class Island 
{
    private int IslandID;
    private String IslandName;
    private int IslandRating;
    private int IslandCapacity; //he maximum number of people (Passes) that can be on the island at any one time
    private ArrayList <Pass> Passes = new ArrayList <Pass>();

    //constructor 
    public Island(int IslandID, String IslandName, int IslandRating, int IslandCapacity) {
        this.IslandID = IslandID;
        this.IslandName = IslandName;
        this.IslandRating = IslandRating;
        this.IslandCapacity = IslandCapacity;
    }

    /* constructor for ArrayList Passes alone becuase if put with the other constructor it will require passes to be entired and it cannot be null
       that would be impractical therefore they are separate*/
    public Island(ArrayList Passes){
        this.Passes = Passes;
    }

    //accessors
    public ArrayList getPasses(){
        return Passes;
    }

    public int getIslandID() {
        return IslandID;
    }

    public String getIslandName() {
        return IslandName;
    }

    public int getIslandRating() {
        return IslandRating;
    }

    public int getIslandCapacity() {
        return IslandCapacity;
    }

    // this method lets the pass details entire inside of the ArrayList of passes inside of the island
    public void enter(Pass InsertPass) {
        String update;
        if(Passes.size() < IslandCapacity){
            Passes.add(InsertPass);
            //System.out.println(Passes);
        }else{
            update = "the capcity of the island is full no more passes accepted";
        }
    }

    //this is to remove the pass from the ArrayList of passes on the islands as they enter another island
    public void leave(Pass InsertPass) {
        int index = Passes.indexOf(InsertPass);
        Passes.remove(index);
        //System.out.println(Passes);
    }

    // this method is to check if the island has enough to capacity to hold the passes and when the limiter is reached or surpassed it does not allow it
    public String CapacityLimit() {
        String CapacityInfo;
        if (Passes.size() >= IslandCapacity){
            CapacityInfo = "The Island reached full capacity";
        }else{
            CapacityInfo = "The Island still has capacity";
        }
        return CapacityInfo;
    }

    // this prints out the current passes on the island all of the passes on the island together
    public String CurrentPasses() {
        return "Passes currently on the Island: " + Passes;
    }

    // This method returns the details of the pass when given only the PassID in the parameters of the method.
    public String PassDetails(int passID) {
        for (Pass ListPass : Passes) {
            if(ListPass.getPassID() == passID) {
                String PD = "Details = " + "(" + "PassID: " + ListPass.getPassID() + "| Name: " + ListPass.getPersonsName() + "| Luxury Rating is: "+ ListPass.getLuxuryRating() + "| Credit: " + ListPass.getCredit() + "| Journey Points: " + ListPass.getJourneyPoints() + ")";
                //System.out.println(PD);
                return PD;
            }
        }
        return "Not Found";
    }

    // This method returns a boolean if the pass is on the island when given only the PassID in the parameters in the method
    public boolean PassOnIsland(int passID){
        for (Pass ListPass : Passes) {
            if(ListPass.getPassID() == passID) {
                return true;
            }
        }    
        return false;
    }

    /*there is 2 toString methods one with the passes inside of the island being listed with the island details and the other 
     * being only island details this is because in the resort itll show the islands that have no passes as "no passes on this island"*/
    public String toString() {
        return "{" + " IslandID = " + getIslandID() + ", IslandName = " + getIslandName() + ", IslandRating = " + getIslandRating() + ", IslandCapacity = " + getIslandCapacity() +  ", Passes = " + "|" + Passes + "|" +"}";
    }

    public String toString1() {
        return "{" + " IslandID = " + getIslandID() + ", IslandName = " + getIslandName() + ", IslandRating = " + getIslandRating() + ", IslandCapacity = " + getIslandCapacity() +"}";
    }
}
