/**
 * A ferry provides a one-way journey between two islands. It
 * has a ferry code and information about both the source and
 * the destination island
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import java.util.*;
public class Ferry
{
    // these are the feilds specified in the assignment specfication 
    private String JourneyCode;
    private Island SourceIsland;
    private Island DestinationIsland;
    private ArrayList <Pass> PassOnFerry = new ArrayList <Pass>();

    //constructor
    public Ferry(String JourneyCode, Island SourceIsland, Island DestinationIsland) {
        this.JourneyCode = JourneyCode;
        this.SourceIsland = SourceIsland;
        this.DestinationIsland = DestinationIsland;
    }

    //accessors 
    public String getJourneyCode() {
        return this.JourneyCode;
    }

    public Island getSourceIsland() {
        return this.SourceIsland;
    }

    public Island getDestinationIsland() {
        return this.DestinationIsland;
    }

    /* this method checks if a passn is able to tavel, it does this by listing all the conditions that need to be met in order for the 
       pass to travel, these conditions are listed and between them is an or operator, therefore if one of the conditions isnt met
       the entire if statment returns false*/
    public boolean PassCanTravel(Pass EnterPass){
        if(EnterPass.getLuxuryRating() < DestinationIsland.getIslandRating() || DestinationIsland.CapacityLimit().equals("The Island reached full capacity") || EnterPass.getCredit() < 3 || SourceIsland.PassOnIsland(EnterPass.getPassID()) == false){
            return false;
        }
        return true;
    }
    
    /* this method applies the changes after the PassCanTravel() method returns true, the changes being the source island is left and
       the pass info is added to the destination island and the ferry cost and benefits are applied and final it shows that the pass is present
       on the ferry, this relays a message that the pass is travelling however if someone ignores the PassCanTravel() method, this method
        will be able to say if the pass is allowed to travel and if it cannot it will return an appropriate response*/
    public String Traveling(Pass p){
        boolean valid = PassCanTravel(p);
        String message = "";
        if (valid == true){
            SourceIsland.leave(p);
            DestinationIsland.enter(p);
            p.UseFerry();
            PassOnFerry.add(p);
            message = "Pass is travelling with no complications";
            return message;
        }
        return "Pass cannot travel due to: not being on the source island or capacity of destination island is full or Luxury rating is low or credit is lower than 3.";
    }

    /* this method converts the array to a string in order to be able to return the passes as a string in the toString() method*/
    public String ArrayToString(){
        String change = "";
        for(Pass i : PassOnFerry){
            change = change + i.toString();
        }
        return change;
    }

    /* the toString() method prints all the information well structured as a string*/
    public String toString() {
        String arr = ArrayToString();
        return "{" + " Journey code = " + getJourneyCode() + ", Source island = " + getSourceIsland() + ", Destination island = " + getDestinationIsland() + ", Passes on the ferry = "+ arr +"}";
    }
}
