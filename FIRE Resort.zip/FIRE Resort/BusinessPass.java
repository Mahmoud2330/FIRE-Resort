
/**
 * Write a description of class BusinessPass here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class BusinessPass extends Pass{
    //feild for this child class
    private int LoyaltyPoints;
    

    //constructor, the feilds in the "super" or parent class are also in the constructor
    public BusinessPass(int ID, String Name, int LuxRating) {
        super (ID, Name, LuxRating, 30); 
        this.LoyaltyPoints = 20;
    }

    // the method of UseFerry here is different from the method in the Pass class as it adds 2 loyalty points
    public void UseFerry(){
        if(super.getCredit()<= 2){

        }else{
            super.minusCredit(3);
            LoyaltyPoints += 2;
        }
        System.out.println("yes it worked" + super.getCredit());
    }
    
    /* the method is similar to the one in the Pass class however instead of converting every 5 points its every 3 points and 
     * this is converting loyalty points into credit*/
    public void ConvertLtoC(){
        if(LoyaltyPoints >= 3){
            int Cred = super.getCredit() + ((LoyaltyPoints - (LoyaltyPoints % 3)) / 3); 
            super.setCredit(Cred);
            LoyaltyPoints = LoyaltyPoints % 3;
        }
    }
    
    //accessor for Loyalty Points
    public int getLoyaltyPoints(){
        return LoyaltyPoints;
    }
    
    //toString method to print the details as a string
    public String toString(){
        
        return "(" + "PassID: " + super.getPassID() + "| Name: " + super.getPersonsName() + "| Luxury Rating is: "+ super.getLuxuryRating() + "| Credit: " + super.getCredit() + "|  Loyalty Points: " + this.LoyaltyPoints +") \n";
    }
}



