
import java.util.*;
/**
 * Write a description of class Tester here.
 * 
 * @author 
 * @version 
 */
public class Tester 
{   
    private void doTest()
    {
        FIRE Wayward = new Resort("", "Wayward Islands Resort.");
        Scanner enter = new Scanner(System.in);
        
        //Write all of your tests here
        /* calling the method withing the resort class is not enough as it has a return 
         * value but it will not output anything for me to see the results and verfiy that it works
         * therefore it i put it in a System.out.println() inorder to look at the results and validate that its working*/
        
        //First started with the toString from the resort class to list all the data possible and it worked successfully
        System.out.println(Wayward.toString());
        
        //This function is called as well from the resort class showing all the passes and where each pass is in all islands and if an island doesnt have passes it lets us know 
        System.out.println(Wayward.getAllPassesOnAllIslands());
        
        //Here when it is given the pass ID the function of findPassLocation takes the ID number
        System.out.println(Wayward.findPassLocation(1001));
        
        /* here the pass details are viewed i entered the first time an existing Pass ID as it will show the details of the pass,
         * to make sure that in the case a user enters a non-existing pass i tested a false Pass ID and it returned that the pass 
         * did not exist */
        System.out.println(Wayward.viewAPass(1003));
        System.out.println(Wayward.viewAPass(1020));
        
        /* here i entered the island name and it returns and prints out the IslandNumber i again tested with a non-existent 
           Island Name in order to see how it will handle it with the user and if it has any logical or runtime error
           */
        System.out.println(Wayward.getIslandNumber("Base"));
        System.out.println(Wayward.getIslandNumber("Fake"));
        
        /* here again i entered the right data and the wrong data. here im supposed to get information on all the passes on the
           specified island which in this case is "Base" and i tested to see if i enter the wrong name what would happen as well as 
           an island with no passes*/
        System.out.println(Wayward.getAllPassesOnIsland("Base"));
        System.out.println(Wayward.getAllPassesOnIsland("Twirl"));
        System.out.println(Wayward.getAllPassesOnIsland("Fake"));
        
        /*here it checks if the pass can travel on the ferry by taking in multiple facotrs, i used first a correct PassID and a correct
         * journey code and then i tested if the PassID was wrong but the journey code was right what would the output be
         * and the third one if the same PassID was written correctly but the journey code was incorrect
           */
        System.out.println(Wayward.canTravel(1003, "ABC1"));
        System.out.println(Wayward.canTravel(1030, "ABC1"));
        System.out.println(Wayward.canTravel(1003, "ABC2"));
        
        /*i used first a correct PassID and a correct journey code and then i tested if the PassID was 
         * wrong but the journey code was right what would the output be and the third one if the same 
         * PassID was written correctly but the journey code was incorrect*/
        System.out.println(Wayward.travel(1001, "ABC1"));
        System.out.println(Wayward.travel(1100, "ABC1"));
        System.out.println(Wayward.travel(1001, "ABC2"));

        /*first i printed out the Pass detailsfor the specfic passID of 1005 and then i topped up the credit with 30 and
           then printed the credit details agian, the reason i did that was so i can see if the difference is applied or not during
           the output*/
        System.out.println(Wayward.viewAPass(1005));
        Wayward.topUpCredits(1005, 30);
        System.out.println(Wayward.viewAPass(1005));
        
        /*firstly i printed the pass details for the passID of 1007 so that i can see the difference i need a before an after of the
           data stored, after i convert the point the credit and journey point are changed and it can be seen becuase
           the pass information is printed before and after the function*/
        System.out.println(Wayward.viewAPass(1007));
        Wayward.convertPoints(1007);
        System.out.println(Wayward.viewAPass(1007));
        
        
        
        
    }
    
    // No need to change this
    public static void main(String[] args)
    {
        Tester xx = new Tester();
        xx.doTest();
    }
}
