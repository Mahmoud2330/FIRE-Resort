import java.util.*;
/**
 * Write a description of class PassTester here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class PassTester
{
    public static void main(String[] args)
    {
        Pass p = new Pass(123,"mahmoud",15,18);
        Pass p1 = new Pass(13,"mahmoud",15,18);
        Pass p2 = new Pass(23,"mahmoud",15,18);

        Island s = new Island(383, "Jamaica", 3, 100);

        s.enter(p);
        s.enter(p1);
        s.enter(p2);

        s.CurrentPasses();
        
        EmployeePass t = new EmployeePass(10001, "Mahmoud", 1022, "works as a hotel manager", 5);
        
        
        t.UseFerry();
        System.out.println(t.toString());
        
        // reminder test alll methods

    }
}
