
/**
 * Write a description of class TouristPass here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class TouristPass extends Pass
{
    //feild for this child class
    private String citizenship;
    
    //constructor, the feilds in the "super" or parent class are also in the constructor
    public TouristPass(int ID, String Name, int LuxRating, int Cred, String citizenship) {
        super (ID, Name, LuxRating, Cred);
        
        this.citizenship = citizenship;
    }
    // used super becuase it refrences the parent class
    /*the method of UseFerry is different here as it minuses 4 from credit and checks that the credit amount 
     * is suffecient to that adjustment*/
    public void UseFerry(){
        if(super.getCredit()<= 3){

        }else{
            super.minusCredit(4);
        }
    }
    
    //accessor 
    public String getCitizenship(){
        return citizenship;
    }

    //to string method that returns all the details as a string
    public String toString(){
        
        return "(" + "PassID: " + super.getPassID() + "| Name: " + super.getPersonsName() + "| Luxury Rating is: "+ super.getLuxuryRating() + "| Credit: " + super.getCredit() + "| Country of Origin: " + this.citizenship + ") \n";
    }
}

